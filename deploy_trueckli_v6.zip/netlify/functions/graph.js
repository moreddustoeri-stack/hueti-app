let cachedToken = null;
let tokenExpiry = 0;

exports.handler = async function(event) {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  };
  if (event.httpMethod === 'OPTIONS') return { statusCode:200, headers:cors, body:'' };
  try {
    const { method, path, body } = JSON.parse(event.body || '{}');
    const token = await getToken();
    const opts = {
      method: method || 'GET',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' }
    };
    if (body && method !== 'DELETE') opts.body = JSON.stringify(body);
    const resp = await fetch(`https://graph.microsoft.com/v1.0${path}`, opts);
    if (resp.status === 204) return { statusCode:204, headers:cors, body:'' };
    const text = await resp.text();
    let data;
    try { data = JSON.parse(text); } catch(e) { data = { raw: text }; }
    return { statusCode:resp.status, headers:{...cors,'Content-Type':'application/json'}, body:JSON.stringify(data) };
  } catch(err) {
    return { statusCode:500, headers:cors, body:JSON.stringify({ error: err.message }) };
  }
};

async function getToken() {
  if (cachedToken && Date.now() < tokenExpiry - 60000) return cachedToken;
  const resp = await fetch(
    `https://login.microsoftonline.com/${process.env.AZURE_TENANT_ID}/oauth2/v2.0/token`,
    { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body: new URLSearchParams({ grant_type:'client_credentials',
        client_id:process.env.AZURE_CLIENT_ID, client_secret:process.env.AZURE_CLIENT_SECRET,
        scope:'https://graph.microsoft.com/.default' }).toString() }
  );
  const data = await resp.json();
  if (!data.access_token) throw new Error('Token error: ' + JSON.stringify(data));
  cachedToken = data.access_token;
  tokenExpiry = Date.now() + data.expires_in * 1000;
  return cachedToken;
}
